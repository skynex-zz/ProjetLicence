<?php

$app = require_once __DIR__ . '/../app/app.php';
$app['debug'] = true;
$app->run();
